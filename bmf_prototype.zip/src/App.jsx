// BMF Interactive - React single-file starter
// Type: code/react
// How to use:
// 1) Create a new React app (Vite recommended):
//    npm create vite@latest bmf -- --template react
//    cd bmf
// 2) Install dependencies:
//    npm install react-router-dom
//    Install Tailwind (follow Tailwind docs) or use the provided simple CSS at bottom.
// 3) Replace src/App.jsx with this file's content and import Tailwind or the CSS file.

import React from "react";
import { BrowserRouter as Router, Routes, Route, Link, useParams } from "react-router-dom";

// NOTE: This single-file example uses Tailwind-like utility classes in the markup.
// If you don't use Tailwind, include the CSS provided at the bottom of this file (in a separate .css)

const Header = () => (
  <header className="bmf-header">
    <div className="bmf-container">
      <div className="bmf-left">
        <div className="bmf-logo">BMF</div>
        <nav className="bmf-nav">
          <Link to="/" className="bmf-link">Nouveautés</Link>
          <Link to="/featured" className="bmf-link">Mises en avant</Link>
          <Link to="/charts" className="bmf-link">Classements</Link>
          <Link to="/catalog" className="bmf-link">Catalogue</Link>
          <Link to="/artists" className="bmf-link">Artistes</Link>
          <Link to="/favorites" className="bmf-link">Favoris</Link>
          <Link to="/about" className="bmf-link">À propos</Link>
        </nav>
      </div>
      <div className="bmf-actions">
        <Link to="/login" className="bmf-cta">Connexion</Link>
      </div>
    </div>
  </header>
);

const Hero = () => (
  <section className="bmf-hero bmf-container">
    <div className="bmf-hero-left">
      <h1 className="bmf-hero-title">MARVEL CARTER<span className="bmf-gradient"> — Exclusive Drop</span></h1>
      <p className="bmf-hero-sub">Nouveau single. Écoute, partage, soutiens.</p>
      <div className="bmf-hero-buttons">
        <Link to="/artists/marvel-carter" className="bmf-btn primary">Écouter</Link>
        <Link to="/featured" className="bmf-btn ghost">Voir les promos</Link>
      </div>
    </div>
    <div className="bmf-hero-right">
      <div className="bmf-banner">Concert virtuel x BMF</div>
    </div>
  </section>
);

const Card = ({item}) => (
  <div className="bmf-card">
    <div className="bmf-card-art" style={{backgroundImage:`url(${item.image})`}} />
    <div className="bmf-card-body">
      <div className="bmf-card-title">{item.title}</div>
      <div className="bmf-card-meta">{item.type} • <span className="bmf-stat">{item.stats}</span></div>
    </div>
  </div>
);

const Home = () => {
  const items = [
    {title: 'Single Hip‑Hop', type: 'Single', stats: '34K', image: '/cover1.jpg'},
    {title: 'Album R&B', type: 'Album', stats: '127K', image: '/cover2.jpg'},
    {title: 'Dancehall Party', type: 'Playlist', stats: '38K', image: '/cover3.jpg'},
    {title: 'EP Electro', type: 'EP', stats: '54K', image: '/cover4.jpg'},
    {title: 'New Single', type: 'Single', stats: '83K', image: '/cover5.jpg'}
  ];

  return (
    <main>
      <Hero />
      <section className="bmf-section bmf-container">
        <h2 className="bmf-section-title">Dernières Sorties</h2>
        <div className="bmf-grid">
          {items.map((it, idx) => <Card item={it} key={idx} />)}
        </div>
      </section>
    </main>
  );
};

const Artists = () => {
  const artists = [
    {id:'marvel-carter', name:'Marvel Carter'},
    {id:'dj-fresh', name:'DJ Fresh'},
    {id:'queen-b', name:'Queen B'},
    {id:'young-wave', name:'Young Wave'}
  ];
  return (
    <section className="bmf-section bmf-container">
      <h2 className="bmf-section-title">Artistes en vedette</h2>
      <div className="bmf-artist-grid">
        {artists.map(a=> (
          <Link to={`/artist/${a.id}`} key={a.id} className="bmf-artist-card">
            <div className="bmf-artist-art" />
            <div className="bmf-artist-name">{a.name}</div>
          </Link>
        ))}
      </div>
    </section>
  );
};

const ArtistProfile = () => {
  const { id } = useParams();
  const fake = {
    name: id.replace('-', ' '),
    bio: 'Bio courte de l\'artiste. Style, influences et nouveautés.'
  };
  return (
    <section className="bmf-section bmf-container">
      <div className="bmf-artist-header">
        <div className="bmf-artist-photo" />
        <div>
          <h2 className="bmf-artist-title">{fake.name}</h2>
          <p className="bmf-artist-bio">{fake.bio}</p>
          <div className="bmf-artist-actions">
            <button className="bmf-btn primary">Suivre</button>
            <button className="bmf-btn ghost">Message</button>
          </div>
        </div>
      </div>

      <div className="bmf-artist-section">
        <h3>Singles & Albums</h3>
        <div className="bmf-grid">
          {[1,2,3,4].map(i => <Card item={{title:'Titre '+i, type:'Single', stats:''+(20*i)+'K', image:'/cover1.jpg'}} key={i} />)}
        </div>
      </div>

    </section>
  );
};

const Login = () => (
  <section className="bmf-section bmf-container">
    <div className="bmf-auth">
      <h2>Connexion</h2>
      <form className="bmf-form" onSubmit={(e)=>{e.preventDefault(); alert('Connexion démo')}}>
        <input placeholder="Email" className="bmf-input" />
        <input placeholder="Mot de passe" type="password" className="bmf-input" />
        <button className="bmf-btn primary" type="submit">Se connecter</button>
      </form>
    </div>
  </section>
);

export default function App(){
  return (
    <Router>
      <div className="bmf-app">
        <Header />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/artists" element={<Artists />} />
          <Route path="/artist/:id" element={<ArtistProfile />} />
          <Route path="/login" element={<Login />} />
          <Route path="/featured" element={<Home />} />
          <Route path="/catalog" element={<Home />} />
          <Route path="/favorites" element={<Home />} />
          <Route path="/about" element={<Home />} />
        </Routes>
      </div>

      {/* Minimal CSS fallback if you don't setup Tailwind. Copy into src/index.css and import it. */}
      <style>{`
      :root{--bg:#080808;--card:#0f0f10;--accent1:#ff3b82;--accent2:#3b8bff;--accent3:#ffd166;}
      *{box-sizing:border-box}
      body{margin:0;background:var(--bg);color:#fff;font-family:Inter,system-ui,Arial}
      .bmf-container{max-width:1200px;margin:0 auto;padding:20px}
      .bmf-header{position:sticky;top:0;background:linear-gradient(180deg,rgba(0,0,0,0.6),transparent);backdrop-filter:blur(6px);border-bottom:1px solid rgba(255,255,255,0.03);z-index:40}
      .bmf-header .bmf-container{display:flex;align-items:center;justify-content:space-between}
      .bmf-logo{font-weight:800;font-size:22px;background:linear-gradient(90deg,var(--accent1),var(--accent2));-webkit-background-clip:text;background-clip:text;color:transparent;padding-right:12px}
      .bmf-nav{display:flex;gap:18px;align-items:center}
      .bmf-link{color:rgba(255,255,255,0.8);text-decoration:none}
      .bmf-cta{background:linear-gradient(90deg,var(--accent1),var(--accent2));padding:8px 14px;border-radius:10px;color:#fff;text-decoration:none}
      .bmf-hero{display:flex;gap:24px;align-items:center;padding:40px 0}
      .bmf-hero-title{font-size:48px;margin:0;background:linear-gradient(90deg,var(--accent3),var(--accent1));-webkit-background-clip:text;background-clip:text;color:transparent}
      .bmf-hero-sub{color:rgba(255,255,255,0.75)}
      .bmf-hero-buttons{margin-top:18px;display:flex;gap:12px}
      .bmf-btn{padding:10px 16px;border-radius:12px;border:none;cursor:pointer;text-decoration:none;display:inline-block}
      .bmf-btn.primary{background:linear-gradient(90deg,var(--accent1),var(--accent2));color:#fff}
      .bmf-btn.ghost{background:rgba(255,255,255,0.03);color:#fff;border:1px solid rgba(255,255,255,0.03)}
      .bmf-banner{background:linear-gradient(90deg,#1b1b1b,#2b2b2b);padding:30px;border-radius:12px;color:#fff}
      .bmf-section{padding:30px 0}
      .bmf-section-title{font-size:22px;margin:0 0 16px}
      .bmf-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:18px}
      .bmf-card{background:linear-gradient(180deg,rgba(255,255,255,0.02),transparent);border-radius:12px;overflow:hidden;border:1px solid rgba(255,255,255,0.03)}
      .bmf-card-art{height:160px;background-size:cover;background-position:center}
      .bmf-card-body{padding:12px}
      .bmf-card-title{font-weight:700}
      .bmf-card-meta{color:rgba(255,255,255,0.6);margin-top:6px}
      .bmf-stat{color:var(--accent3);font-weight:700}
      .bmf-artist-grid{display:flex;gap:18px}
      .bmf-artist-card{display:block;text-decoration:none;color:inherit;width:160px}
      .bmf-artist-art{height:140px;background:linear-gradient(90deg,var(--accent1),var(--accent2));border-radius:8px}
      .bmf-artist-name{margin-top:10px}
      .bmf-auth{max-width:420px;margin:40px auto;padding:24px;background:linear-gradient(180deg,rgba(255,255,255,0.02),transparent);border-radius:12px}
      .bmf-form{display:flex;flex-direction:column;gap:12px}
      .bmf-input{padding:10px;border-radius:8px;border:1px solid rgba(255,255,255,0.04);background:transparent;color:#fff}
      @media (max-width:800px){.bmf-nav{display:none}.bmf-hero{flex-direction:column}}
      `}</style>
    </Router>
  );
}
